package com.fitapp.sdp.fitnessapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity{

    public DatabaseHelper fitAppDb;

    private float weight, height, neckWid, lBicep, rBicep,
    chestWid,lForearm,rForearm,waistWid,lThigh,rThigh,lCalf,rCalf;

    private EditText weightInput,heightInput,outputBMI;

    private EditText neckMes,lBicepMes,rBicepMes,chestMes,lForearmMes,
    rForearmMes,waistMes,lThighMes,rThighMes,lCalfMes,rCalfMes;

    private Button calcBMI;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fitAppDb = DatabaseHelper.getInstance(this);
    }


    public void measurementInput(View view) {
        setContentView(R.layout.measurements);

        neckMes = (EditText) findViewById(R.id.neckMes);
        lBicepMes = (EditText) findViewById(R.id.lBicepMes);
        rBicepMes = (EditText) findViewById(R.id.rBicepMes);
        chestMes = (EditText) findViewById(R.id.chestMes);
        lForearmMes = (EditText) findViewById(R.id.lForearmMes);
        rForearmMes = (EditText) findViewById(R.id.rForearmMes);
        waistMes = (EditText) findViewById(R.id.waistMes);
        lThighMes = (EditText) findViewById(R.id.lThighMes);
        rThighMes = (EditText) findViewById(R.id.rThighMes);
        lCalfMes = (EditText) findViewById(R.id.lCalfMes);
        rCalfMes = (EditText) findViewById(R.id.rCalfMes);

        neckWid = Float.valueOf(neckMes.getText().toString());
        lBicep = Float.valueOf(lBicepMes.getText().toString());
        rBicep = Float.valueOf(rBicepMes.getText().toString());
        chestWid = Float.valueOf(chestMes.getText().toString());
        lForearm = Float.valueOf(lForearmMes.getText().toString());
        rForearm = Float.valueOf(rForearmMes.getText().toString());
        waistWid = Float.valueOf(neckMes.getText().toString());
        lThigh = Float.valueOf(neckMes.getText().toString());
        rThigh = Float.valueOf(neckMes.getText().toString());
        lCalf = Float.valueOf(neckMes.getText().toString());
        rCalf = Float.valueOf(neckMes.getText().toString());

//        System.out.println(""+rCalf);

    }
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);
//    }

    public void openMeasurements(View view)
    {
        setContentView(R.layout.measurements);
    }

    public void openMyProgress(View view)
    {
        setContentView(R.layout.my_progress);
    }

    public void openBMICalculator(View view)
    {
        setContentView(R.layout.bmi_calc);
        weightInput = (EditText) findViewById(R.id.weightInput);
        heightInput = (EditText) findViewById(R.id.heightInput);
        outputBMI = (EditText) findViewById(R.id.outputBMI);
        calcBMI = (Button) findViewById(R.id.calcBMI);

        calcBMI.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String sWeight = weightInput.getText().toString();
                String sHeight = heightInput.getText().toString();

                if(!sWeight.equals("") && !sHeight.equals(""))
                {
                    weight = Float.valueOf(sWeight);
                    height = Float.valueOf(sHeight);

                    float BMI = weight / (height * height);

                    outputBMI.setText(""+BMI);
                }
            }
        });
    }

     public void openExerciseBodyParts(View view)
     {
         setContentView(R.layout.exercise_body_parts);
     }

     public void openStretchesBodyParts(View view)
     {
        setContentView(R.layout.stretches_body_parts);

     }

     public void openMainMenu(View view)
     {
         setContentView(R.layout.activity_main);
     }

     public void openArmExercisesScreen(View view)
     {
         setContentView(R.layout.arms_exercises_screen);
     }

     /******************** Stretches Views *********************************/
    public void openNeckStretches(View view)
    {
        setContentView(R.layout.neck_stretches);
    }

    public void openChestStretches(View view)
    {
        setContentView(R.layout.chest_stretches);
    }

    public void openShoulderStretches(View view)
    {
        setContentView(R.layout.shoulder_stretches);
    }

    public void openArmStretches(View view)
    {
        setContentView(R.layout.arm_stretches);
    }

    public void openCoreStretches(View view)
    {
        setContentView(R.layout.core_stretches);
    }

    public void openBackStretches(View view)
    {
        setContentView(R.layout.back_stretches);
    }

    public void openLegStretches(View view)
    {
        setContentView(R.layout.leg_stretches);
    }

    public void openBicepStretches(View view)
    {
        setContentView(R.layout.bicep_stretches);
    }

    public void openTricepStretches(View view)
    {
        setContentView(R.layout.tricep_stretches);
    }

    public void openForearmStretches(View view)
    {
        setContentView(R.layout.forearm_stretches);
    }

    public void openQuadStretches(View view)
    {
        setContentView(R.layout.quad_stretches);
    }

    public void openHamstringStretches(View view)
    {
        setContentView(R.layout.hamstring_stretches);
    }

    public void openCalveStretches(View view)
    {
        setContentView(R.layout.calve_stretches);
    }

   /******************Exercises Views *****************************/
   public void openNeckExercises(View view)
   {
       setContentView(R.layout.neck_exercises);
   }

    public void openChestExercises(View view)
    {
        setContentView(R.layout.chest_exercises);
    }

    public void openShoulderExercises(View view)
    {
        setContentView(R.layout.shoulder_exercises);
    }

    public void openArmExercises(View view)
    {
        setContentView(R.layout.arm_exercises);
    }

    public void openCoreExercises(View view)
    {
        setContentView(R.layout.core_exercises);
    }

    public void openBackExercises(View view)
    {
        setContentView(R.layout.back_exercises);
    }

    public void openLegExercises(View view)
    {
        setContentView(R.layout.leg_exercises);
    }

    public void openBicepExercises(View view)
    {
        setContentView(R.layout.bicep_exercises);
    }

    public void openTricepExercises(View view)
    {
        setContentView(R.layout.tricep_exercises);
    }

    public void openForearmExercises(View view)
    {
        setContentView(R.layout.forearm_exercises);
    }

    public void openQuadExercises(View view)
    {
        setContentView(R.layout.quad_exercises);
    }

    public void openHamstringExercises(View view)
    {
        setContentView(R.layout.hamstring_exercises);
    }

    public void openCalvesExercises(View view)
    {
        setContentView(R.layout.calves_exercises);
    }

    public void openWorkouts(View view)
    {
        setContentView(R.layout.workouts);
    }

    public void openNutrition(View view)
    {
        setContentView(R.layout.nutrition);
    }

    public void openHelp(View view)
    {
        setContentView(R.layout.help);
    }

    /*************************** Workouts *************************************/

    public void openChestWorkouts(View view)
    {
        setContentView(R.layout.chest_workouts);
    }
    public void openShoulderWorkouts(View view)
    {
        setContentView(R.layout.shoulder_workouts);
    }
    public void openArmWorkouts(View view)
    {
        setContentView(R.layout.arm_workouts);
    }
    public void openCoreWorkouts(View view)
    {
        setContentView(R.layout.core_workouts);
    }
    public void openBackWorkouts(View view)
    {
        setContentView(R.layout.back_workouts);
    }
    public void openLegWorkouts(View view)
    {
        setContentView(R.layout.leg_workouts);
    }
    public void openWholeBodyWorkouts(View view)
    {
        setContentView(R.layout.wholebody_workouts);
    }
    public void openCardioWorkouts(View view)
    {
        setContentView(R.layout.cardio_workouts);
    }

    /**************************** Exercises ***********************************/

    public void openBenchPress(View view)
    {
        setContentView(R.layout.bench_press);
    }

    public void openInclineBenchPress(View view)
    {
        setContentView(R.layout.incline_bench_press);
    }

    public void openDeclineBenchPress(View view)
    {
        setContentView(R.layout.decline_bench_press);
    }


}

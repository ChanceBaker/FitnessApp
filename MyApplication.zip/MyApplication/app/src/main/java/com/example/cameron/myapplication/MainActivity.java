package com.example.cameron.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    float weight;
    float height;

    float neckWid;
    float lBicep;
    float rBicep;
    float chestWid;
    float lForearm;
    float rForearm;
    float waistWid;
    float lThigh;
    float rThigh;
    float lCalf;
    float rCalf;

    EditText weightInput;
    EditText heightInput;
    EditText outputBMI;

    EditText neckMes;
    EditText lBicepMes;
    EditText rBicepMes;
    EditText chestMes;
    EditText lForearmMes;
    EditText rForearmMes;
    EditText waistMes;
    EditText lThighMes;
    EditText rThighMes;
    EditText lCalfMes;
    EditText rCalfMes;

    Button calcBMI;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        weightInput = (EditText) findViewById(R.id.weightInput);
        heightInput = (EditText) findViewById(R.id.heightInput);
        outputBMI = (EditText) findViewById(R.id.outputBMI);
        calcBMI = (Button) findViewById(R.id.calcBMI);

        calcBMI.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String sWeight = weightInput.getText().toString();
                String sHeight = heightInput.getText().toString();

                weight = Float.valueOf(sWeight);
                height = Float.valueOf(sHeight);

                float BMI = weight / (height * height);

                outputBMI.setText(""+BMI);


            }
        });
    }

    protected void measurementInput(Bundle savedInstanceState) {
        setContentView(R.layout.measurements);

        neckMes = (EditText) findViewById(R.id.neckMes);
        lBicepMes = (EditText) findViewById(R.id.lBicepMes);
        rBicepMes = (EditText) findViewById(R.id.rBicepMes);
        chestMes = (EditText) findViewById(R.id.chestMes);
        lForearmMes = (EditText) findViewById(R.id.lForearmMes);
        rForearmMes = (EditText) findViewById(R.id.rForearmMes);
        waistMes = (EditText) findViewById(R.id.waistMes);
        lThighMes = (EditText) findViewById(R.id.lThighMes);
        rThighMes = (EditText) findViewById(R.id.rThighMes);
        lCalfMes = (EditText) findViewById(R.id.lCalfMes);
        rCalfMes = (EditText) findViewById(R.id.rCalfMes);

        neckWid = Float.valueOf(neckMes.getText().toString());
        lBicep = Float.valueOf(lBicepMes.getText().toString());
        rBicep = Float.valueOf(rBicepMes.getText().toString());
        chestWid = Float.valueOf(chestMes.getText().toString());
        lForearm = Float.valueOf(lForearmMes.getText().toString());
        rForearm = Float.valueOf(rForearmMes.getText().toString());
        waistWid = Float.valueOf(neckMes.getText().toString());
        lThigh = Float.valueOf(neckMes.getText().toString());
        rThigh = Float.valueOf(neckMes.getText().toString());
        lCalf = Float.valueOf(neckMes.getText().toString());
        rCalf = Float.valueOf(neckMes.getText().toString());

        System.out.println(""+rCalf);

    }



}

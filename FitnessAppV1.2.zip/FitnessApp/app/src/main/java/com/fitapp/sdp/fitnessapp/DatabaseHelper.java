package com.fitapp.sdp.fitnessapp;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.annotation.Nullable;
import android.util.Log;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static DatabaseHelper sInstance;
    public static final String DATABASE_NAME = "fitnessapp.db";

    public static final String PROGRESS_TABLE = "progress_table";
    public static final String P_ID = "ID";
    public static final String P_WEIGHT = "WEIGHT";
    public static final String P_DATE = "DATE";

    public static final String MEASURE_TABLE = "measurements_table";
    public static final String M_ID = "ID";
    public static final String M_DATE = "DATE";
    public static final String M_NECK = "NECK";
    public static final String M_CHEST = "CHEST";
    public static final String M_L_BICEP = "L_BICEP";
    public static final String M_L_FOREARM = "L_FOREARM";
    public static final String M__R_BICEP = "R_BICEP";
    public static final String M_R_FOREARM = "R_FOREARM";
    public static final String M_WAIST = "WAIST";
    public static final String M_L_THIGH = "L_THIGH";
    public static final String M_R_THIGH = "R_THIGH";
    public static final String M_L_CALF = "L_CALF";
    public static final String M_R_CALF = "R_CALF";

    private DatabaseHelper(@Nullable Context context) {
        super(context, DATABASE_NAME,null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

            String create = "CREATE TABLE IF NOT EXISTS ";

            Log.i("Fitness App","Getting to here");
            db.execSQL(create + PROGRESS_TABLE + "(P_ID INTEGER PRIMARY KEY AUTOINCREMENT, P_WEIGHT DECIMAL(3,2), P_DATE TEXT)");
            Log.i("Fitness App","Progress Table Created");

            db.execSQL(create + MEASURE_TABLE + "(M_ID INTEGER PRIMARY KEY AUTOINCREMENT, M_DATE TEXT, M_NECK DECIMAL(3,1), M_CHEST DECIMAL(3,1) " +
                    ",M_L_BICEP DECIMAL(3,2), M_L_FOREARM DECIMAL(3,2), M_R_BICEP DECIMAL(3,1), M_R_FOREARM DECIMAL(3,1), M_WAIST DECIMAL(3,1)" +
                    ", M_L_THIGH DECIMAL(3,1), M_R_THIGH DECIMAL(3,1), M_L_CALF DECIMAL(3,1), M_R_CALF DECIMAL(3,1))");
            Log.i("Fitness App","Measurement Table Created");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + PROGRESS_TABLE);
        System.out.println(PROGRESS_TABLE + " Dropped");
        db.execSQL("DROP TABLE IF EXISTS " + MEASURE_TABLE);
        System.out.println(MEASURE_TABLE + " Dropped");
        onCreate(db);
    }

    public static synchronized DatabaseHelper getInstance(Context context) {

        if (sInstance == null) {
            sInstance = new DatabaseHelper(context.getApplicationContext());
        }
        return sInstance;
    }
}
